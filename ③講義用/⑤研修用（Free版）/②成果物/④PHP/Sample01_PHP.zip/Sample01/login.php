<?php
declare(strict_types=1);

require_once __DIR__ . '/src/Helpers.php';
require_once __DIR__ . '/src/Auth.php';

header('Content-Type: text/html; charset=UTF-8');

$errorMessage = null;

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    // 未送信(null)や文字列以外は空文字として扱う
    $username = is_string($_POST['username'] ?? null) ? $_POST['username'] : '';
    $password = is_string($_POST['password'] ?? null) ? $_POST['password'] : '';

    try {
        $ok = Auth::login($username, $password);
    } catch (Throwable $e) {
        renderServerError($e);
    }

    if ($ok) {
        header('Location: products.php');
        exit;
    }
    $errorMessage = 'ユーザ名またはパスワードが正しくありません。';
}

define('APP_RUNNING', true);
require __DIR__ . '/templates/login.php';
