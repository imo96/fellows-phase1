<?php
declare(strict_types=1);

/**
 * HTML エスケープ(画面に出力する値は必ずこの関数を通す)
 */
function h(mixed $v): string
{
    return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8');
}

/**
 * 日付(Y-m-d)を yyyy/MM/dd 形式にする
 */
function formatDate(?string $date): string
{
    if ($date === null || $date === '') {
        return '';
    }
    return (new DateTimeImmutable($date))->format('Y/m/d');
}

/**
 * 3桁カンマ区切り
 */
function formatInt(int $n): string
{
    return number_format($n);
}

/**
 * 符号付き・3桁カンマ区切り(0 は符号なし)。NULL は空欄
 */
function formatSigned(?int $n): string
{
    if ($n === null) {
        return '';
    }
    if ($n > 0) {
        return '+' . number_format($n);
    }
    if ($n < 0) {
        return '-' . number_format(abs($n));
    }
    return '0';
}

/**
 * 想定外のエラー時の応答(詳細は画面に出さずログへ)
 */
function renderServerError(Throwable $e): never
{
    error_log((string)$e);
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: text/html; charset=UTF-8');
    }
    echo '<!DOCTYPE html><html lang="ja"><head><meta charset="UTF-8"><title>エラー</title></head><body>'
        . '<p>システムエラーが発生しました。しばらくしてからやり直してください。</p>'
        . '</body></html>';
    exit;
}
