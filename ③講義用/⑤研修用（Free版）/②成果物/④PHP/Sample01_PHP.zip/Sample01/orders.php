<?php
declare(strict_types=1);

require_once __DIR__ . '/src/Helpers.php';
require_once __DIR__ . '/src/Auth.php';
require_once __DIR__ . '/src/Repository.php';

Auth::requireLogin();

$code = $_GET['code'] ?? '';
$code = is_string($code) ? trim($code) : '';
if ($code === '') {
    header('Location: products.php');
    exit;
}

header('Content-Type: text/html; charset=UTF-8');

try {
    $records = Repository::findOrdersByProductCode($code);
} catch (Throwable $e) {
    renderServerError($e);
}

$orders = [];
foreach ($records as $r) {
    $coupon = $r['coupon'] === null ? null : (int)$r['coupon'];
    $orders[] = [
        'date'    => formatDate((string)$r['order_date']),
        'no'      => (string)$r['order_no'],
        'branch'  => formatInt((int)$r['order_branch']),
        'qty'     => formatInt((int)$r['quantity']),
        'coupon'  => formatSigned($coupon),
        'isMinus' => $coupon !== null && $coupon < 0,
    ];
}

define('APP_RUNNING', true);
require __DIR__ . '/templates/order_detail.php';
