<?php
declare(strict_types=1);
if (!defined('APP_RUNNING')) { http_response_code(403); exit; }
?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>商品一覧 | ClaudeCode 研修用プログラム</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="list-page">
<header class="app-header">
  <img class="logo" src="logo.svg" alt="ロゴ">
  <span class="app-name">ClaudeCode 研修用プログラム</span>
  <span class="spacer"></span>
  <form method="post" action="logout.php">
    <button type="submit" class="btn btn-outline">ログアウト</button>
  </form>
</header>

<main class="content">
  <div class="page-title">
    <h1>商品一覧画面</h1>
  </div>

  <div class="table-card">
    <table>
      <thead>
        <tr>
          <th>商品コード</th>
          <th>商品名</th>
          <th class="num">単価</th>
          <th>商品区分</th>
          <th>関連商品コード</th>
          <th>注文状況</th>
        </tr>
      </thead>
      <tbody>
<?php foreach ($products as $p): ?>
        <tr>
          <td class="code"><?= h($p['code']) ?></td>
          <td class="name"><?= h($p['name']) ?></td>
          <td class="num"><?= h($p['price']) ?></td>
          <td><span class="badge"><?= h($p['category']) ?></span></td>
<?php if ($p['related'] !== null): ?>
          <td><span class="code"><?= h($p['related']) ?></span></td>
<?php else: ?>
          <td><span class="muted">―</span></td>
<?php endif; ?>
<?php if ($p['count'] > 0): ?>
          <td><a class="order-link" href="<?= h($p['orderUrl']) ?>">注文(<?= h($p['count']) ?> 件)</a></td>
<?php else: ?>
          <td><span class="muted">注文なし</span></td>
<?php endif; ?>
        </tr>
<?php endforeach; ?>
      </tbody>
    </table>
  </div>
</main>
</body>
</html>
