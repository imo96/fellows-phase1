<?php
declare(strict_types=1);
if (!defined('APP_RUNNING')) { http_response_code(403); exit; }
?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>注文情報 | ClaudeCode 研修用プログラム</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="list-page">
<header class="app-header">
  <img class="logo" src="logo.svg" alt="ロゴ">
  <span class="app-name">ClaudeCode 研修用プログラム</span>
  <span class="spacer"></span>
  <form method="post" action="logout.php">
    <button type="submit" class="btn btn-outline">ログアウト</button>
  </form>
</header>

<main class="content">
  <div class="page-title">
    <h1>注文情報詳細画面</h1>
    <span class="sub">商品コード:<strong class="code"><?= h($code) ?></strong></span>
  </div>

  <div class="table-card">
    <table>
      <thead>
        <tr>
          <th>注文日</th>
          <th>注文番号</th>
          <th class="num">注文枝番</th>
          <th class="num">数量</th>
          <th class="num">クーポン割引料</th>
        </tr>
      </thead>
      <tbody>
<?php foreach ($orders as $o): ?>
        <tr>
          <td><?= h($o['date']) ?></td>
          <td class="code"><?= h($o['no']) ?></td>
          <td class="num"><?= h($o['branch']) ?></td>
          <td class="num"><?= h($o['qty']) ?></td>
          <td class="num<?= $o['isMinus'] ? ' minus' : '' ?>"><?= h($o['coupon']) ?></td>
        </tr>
<?php endforeach; ?>
<?php if ($orders === []): ?>
        <tr>
          <td colspan="5"><span class="muted">該当する注文はありません。</span></td>
        </tr>
<?php endif; ?>
      </tbody>
    </table>
  </div>

  <div class="page-footer">
    <a class="back-link" href="products.php">&larr; 商品一覧に戻る</a>
  </div>
</main>
</body>
</html>
