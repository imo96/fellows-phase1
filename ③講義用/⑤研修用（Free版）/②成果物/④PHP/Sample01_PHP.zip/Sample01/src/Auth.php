<?php
declare(strict_types=1);

require_once __DIR__ . '/Db.php';

final class Auth
{
    private const SESSION_KEY = 'loginUser';

    public static function startSession(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_set_cookie_params([
                'httponly' => true,
                'samesite' => 'Lax',
                'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
            ]);
            session_start();
        }
    }

    public static function isLoggedIn(): bool
    {
        return isset($_SESSION[self::SESSION_KEY]);
    }

    /**
     * 未ログインならログイン画面へリダイレクトする
     */
    public static function requireLogin(): void
    {
        self::startSession();
        if (!self::isLoggedIn()) {
            header('Location: login.php');
            exit;
        }
        // ログアウト後に戻るボタンで画面が再表示されないようにする
        header('Cache-Control: no-store');
    }

    /**
     * ユーザ名(eメール)とパスワード(SHA-256)で認証する。成功時はセッションに保存する
     */
    public static function login(string $username, string $password): bool
    {
        if ($username === '' || $password === '') {
            return false;
        }

        $stmt = Db::connect()->prepare('SELECT "パスワード" AS password FROM "ユーザー情報" WHERE "eメール" = ?');
        $stmt->execute([$username]);

        $inputHash = hash('sha256', $password);
        $matched = false;
        foreach ($stmt->fetchAll() as $row) {
            if (hash_equals((string)$row['password'], $inputHash)) {
                $matched = true;
            }
        }
        if (!$matched) {
            return false;
        }

        self::startSession();
        session_regenerate_id(true);
        $_SESSION[self::SESSION_KEY] = $username;
        return true;
    }

    public static function logout(): void
    {
        self::startSession();
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', [
                'expires'  => time() - 42000,
                'path'     => $p['path'],
                'domain'   => $p['domain'],
                'secure'   => $p['secure'],
                'httponly' => $p['httponly'],
                'samesite' => $p['samesite'] ?: 'Lax',
            ]);
        }
        session_destroy();
    }
}
