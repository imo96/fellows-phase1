<?php
declare(strict_types=1);

require_once __DIR__ . '/src/Helpers.php';
require_once __DIR__ . '/src/Auth.php';
require_once __DIR__ . '/src/Repository.php';

Auth::requireLogin();
header('Content-Type: text/html; charset=UTF-8');

try {
    $records = Repository::findProductList();
} catch (Throwable $e) {
    renderServerError($e);
}

$products = [];
foreach ($records as $r) {
    $count = (int)$r['order_count'];
    $code  = (string)$r['product_code'];
    $products[] = [
        'code'     => $code,
        'name'     => mb_substr((string)$r['product_name'], 0, 25, 'UTF-8'), // 25文字まで表示
        'price'    => formatInt((int)$r['unit_price']),
        'category' => (string)$r['category'],
        'related'  => ($r['related_code'] === null || $r['related_code'] === '') ? null : (string)$r['related_code'],
        'count'    => $count,
        'orderUrl' => 'orders.php?code=' . urlencode($code),
    ];
}

define('APP_RUNNING', true);
require __DIR__ . '/templates/product_list.php';
