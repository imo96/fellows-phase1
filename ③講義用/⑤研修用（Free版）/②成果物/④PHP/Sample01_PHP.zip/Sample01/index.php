<?php
declare(strict_types=1);

// ウェルカムページ: ログイン画面へ転送する
header('Location: login.php');
exit;
