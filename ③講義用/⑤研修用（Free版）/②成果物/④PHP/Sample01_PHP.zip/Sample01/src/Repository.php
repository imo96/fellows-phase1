<?php
declare(strict_types=1);

require_once __DIR__ . '/Db.php';

/**
 * データの読み取り(SELECT)専用
 */
final class Repository
{
    /**
     * 商品一覧情報(商品 LEFT JOIN 注文)。商品コード昇順
     *
     * @return list<array<string, mixed>>
     */
    public static function findProductList(): array
    {
        $sql = <<<'SQL'
            SELECT p."商品コード"     AS product_code,
                   p."商品名"         AS product_name,
                   p."単価"           AS unit_price,
                   p."商品区分"       AS category,
                   p."関連商品コード" AS related_code,
                   COUNT(DISTINCT (o."注文日", o."注文番号"))
                       FILTER (WHERE o."注文番号" IS NOT NULL) AS order_count
              FROM "商品" p
              LEFT JOIN "注文" o ON o."商品コード" = p."商品コード"
             GROUP BY p."商品コード", p."商品名", p."単価", p."商品区分", p."関連商品コード"
             ORDER BY p."商品コード" ASC
            SQL;

        return Db::connect()->query($sql)->fetchAll();
    }

    /**
     * 指定商品コードの注文。注文日降順、注文番号降順、注文枝番昇順
     *
     * @return list<array<string, mixed>>
     */
    public static function findOrdersByProductCode(string $code): array
    {
        $sql = <<<'SQL'
            SELECT "注文日"         AS order_date,
                   "注文番号"       AS order_no,
                   "注文枝番"       AS order_branch,
                   "数量"           AS quantity,
                   "クーポン割引料" AS coupon
              FROM "注文"
             WHERE "商品コード" = ?
             ORDER BY "注文日" DESC, "注文番号" DESC, "注文枝番" ASC
            SQL;

        $stmt = Db::connect()->prepare($sql);
        $stmt->execute([$code]);
        return $stmt->fetchAll();
    }
}
