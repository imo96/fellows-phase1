<?php
declare(strict_types=1);
if (!defined('APP_RUNNING')) { http_response_code(403); exit; }
?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ログイン | ClaudeCode 研修用プログラム</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<main class="login-page">
  <div class="login-card">
    <img class="logo" src="logo.svg" alt="ロゴ">
    <p class="app-name">ClaudeCode 研修用プログラム</p>
    <h1>ログイン画面</h1>

<?php if ($errorMessage !== null): ?>
    <p class="error-message"><?= h($errorMessage) ?></p>
<?php endif; ?>

    <form method="post" action="login.php">
      <div class="field">
        <label for="username">ユーザ名</label>
        <input type="text" id="username" name="username" autocomplete="username" required autofocus>
      </div>
      <div class="field">
        <label for="password">パスワード</label>
        <input type="password" id="password" name="password" autocomplete="current-password" required>
      </div>
      <button type="submit" class="btn btn-primary">ログイン</button>
    </form>
  </div>
</main>
</body>
</html>
