<?php
declare(strict_types=1);

final class Db
{
    /** サーバー(AWS)の接続情報ファイル。公開フォルダの外に置く */
    private const SERVER_CONFIG = '/etc/php-app/config.php';

    /** ローカル(XAMPP)用の接続情報ファイル。デプロイのアーカイブには含めない */
    private const LOCAL_INI = __DIR__ . '/../config/db.ini';

    private static ?PDO $pdo = null;

    public static function connect(): PDO
    {
        if (self::$pdo !== null) {
            return self::$pdo;
        }

        [$dsn, $user, $password] = is_file(self::SERVER_CONFIG)
            ? self::loadServerConfig()
            : self::loadLocalIni();

        self::$pdo = new PDO($dsn, $user, $password, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);

        return self::$pdo;
    }

    /**
     * サーバー: /etc/php-app/config.php(dsn / user / password を返す配列)を読む
     *
     * @return array{0: string, 1: string, 2: string}
     */
    private static function loadServerConfig(): array
    {
        $cfg = require self::SERVER_CONFIG;
        if (!is_array($cfg)) {
            throw new RuntimeException(self::SERVER_CONFIG . ' の形式が正しくありません。');
        }
        foreach (['dsn', 'user', 'password'] as $key) {
            if (!array_key_exists($key, $cfg)) {
                throw new RuntimeException(self::SERVER_CONFIG . " に {$key} がありません。");
            }
        }

        $dsn = (string)$cfg['dsn'];
        if (stripos($dsn, 'client_encoding=') === false) {
            $dsn .= ';client_encoding=UTF8';
        }
        return [$dsn, (string)$cfg['user'], (string)$cfg['password']];
    }

    /**
     * ローカル: config/db.ini を読む
     *
     * @return array{0: string, 1: string, 2: string}
     */
    private static function loadLocalIni(): array
    {
        $ini = parse_ini_file(self::LOCAL_INI, false, INI_SCANNER_RAW);
        if ($ini === false) {
            throw new RuntimeException('config/db.ini を読み込めません。');
        }
        foreach (['db.host', 'db.port', 'db.name', 'db.user', 'db.password'] as $key) {
            if (!array_key_exists($key, $ini)) {
                throw new RuntimeException("config/db.ini に {$key} がありません。");
            }
        }

        $dsn = sprintf(
            'pgsql:host=%s;port=%s;dbname=%s;client_encoding=UTF8',
            $ini['db.host'],
            $ini['db.port'],
            $ini['db.name']
        );
        return [$dsn, (string)$ini['db.user'], (string)$ini['db.password']];
    }
}
