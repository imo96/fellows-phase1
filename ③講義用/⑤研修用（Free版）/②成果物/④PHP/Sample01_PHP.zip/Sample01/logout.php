<?php
declare(strict_types=1);

require_once __DIR__ . '/src/Auth.php';

// POST 以外は何もせずログイン画面へ
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    header('Location: login.php');
    exit;
}

Auth::logout();
header('Location: login.php');
exit;
